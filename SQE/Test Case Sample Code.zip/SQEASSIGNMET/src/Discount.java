public class Discount {
       double calculateDiscount(String clothingType, double purchaseAmount) {
            double discount = 0.0;
            if (purchaseAmount > 100) {
                discount += 20; // $20 discount
            }
            if (clothingType.equalsIgnoreCase("shirt")) {
                discount += 10; // $10 discount for shirts
            }
            if (purchaseAmount > 50 && clothingType.equalsIgnoreCase("pants")) {
                discount += 15; // $15 discount for pants
            }
            if (discount == 0) {
                discount += 5; // $5 discount as a default
            }
            return discount;
        }
    }
