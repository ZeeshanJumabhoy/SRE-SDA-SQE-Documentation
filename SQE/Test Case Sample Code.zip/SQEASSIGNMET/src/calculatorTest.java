import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
class calculatorTest {
    @Test
    void add() {
        calculator obj=new calculator();
        assertEquals(64,obj.add(35,29));
        assertEquals(98,obj.add(10,11));
        assertEquals(122,obj.add(100,22));
    }
    @Test
    void subtract() {
        calculator obj=new calculator();
        assertEquals(6,obj.subtract(35,29));
        assertEquals(98,obj.subtract(10,11));
    }
    @Test
    void multiply() {
        calculator obj=new calculator();
        assertEquals(1015,obj.multiply(35,29));
        assertEquals(98,obj.multiply(10,11));
    }
    @Test
    void divide() {
        calculator obj=new calculator();
        assertEquals((double) 35 /29,obj.divide(35,29));
        assertEquals(Double.NaN,obj.divide(35,0));
        assertEquals(98,obj.divide(10,11));
    }
}