import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DiscountTest {

    @Test
    void calculateDiscount() {
        Discount obj=new Discount();
        assertEquals(30,obj.calculateDiscount("shirt",120));
        assertEquals(35,obj.calculateDiscount("pants",120));
        assertEquals(5,obj.calculateDiscount("joggers",85));
        assertEquals(5,obj.calculateDiscount("shirt",-25));
    }
}