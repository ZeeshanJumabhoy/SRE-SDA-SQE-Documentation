import java.util.Scanner;
class calculator{
    double a;
    double b;
    double add(double a, double b) {
        return a + b;
    }
    double subtract(double a, double b) {
        return a - b;
    }
    double multiply(double a, double b) {
        return a * b;
    }
    double divide(double a, double b) {
        if (b != 0) {
            return a / b;
        } else {
            System.out.println("Error: Cannot divide by zero.");
            return Double.NaN;
        }
    }
}
public class Main {
    public static void main(String[] args) {
        calculator obj=new calculator();
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the value of A");
        double b=sc.nextDouble();
        System.out.println("Enter the value of B");
        double c= sc.nextDouble();
        System.out.println("the value is "+ obj.add(b,c));
        System.out.println("the value is "+ obj.subtract(b,c));
        System.out.println("the value is "+ obj.multiply(b,c));
        System.out.println("the value is "+ obj.divide(b,c));
        System.out.print("Enter the type of clothing (shirt/pants): ");
        String clothingType = sc.nextLine();

        System.out.print("Enter the total purchase amount: $");
        double purchaseAmount = sc.nextDouble();
Discount obj1=new Discount();
        double discount = obj1.calculateDiscount(clothingType, purchaseAmount);

        // Display the final amount after discount
        double discountedAmount = purchaseAmount - discount;
        System.out.println("\nTotal Purchase Amount: $" + purchaseAmount);
        System.out.println("Discount Applied: $" + discount);
        System.out.println("Discounted Amount: $" + discountedAmount);

        // Close the scanner
        sc.close();
    }
}