import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FizzBuzzTest {

    @Test
    void fizzBuz() {
        FizzBuzz obj=new FizzBuzz();
        assertEquals("FizzBuzz",obj.FizzBuz(15));
    }
}