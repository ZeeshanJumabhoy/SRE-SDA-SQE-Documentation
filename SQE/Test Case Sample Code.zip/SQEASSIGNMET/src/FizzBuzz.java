public class FizzBuzz {
    public String FizzBuz(int i)
    {
        StringBuilder result = new StringBuilder();
            if (i % 3 == 0 && i % 5 == 0) {
                result.append("FizzBuzz ");
            } else if (i % 3 == 0) {
                result.append("Fizz ");
            } else if (i % 5 == 0) {
                result.append("Buzz ");
            } else {
                result.append(i).append(" ");
            }
        return result.toString().trim();
    }
}
